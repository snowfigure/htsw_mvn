package org.outstudio.wxtest;

import org.outstudio.wxtest.ui.MainFrame;

public class Main {

	public static void main(String[] args) {
		MainFrame.launch();
	}

}
