EasyWechat
==========

EasyWechat is a Java framework for creating Wechat Public Platform applications with easy-to-use API.

tutorial: http://blog.csdn.net/u010182075/article/details/38339393

EasyWechat交流群：243699390
