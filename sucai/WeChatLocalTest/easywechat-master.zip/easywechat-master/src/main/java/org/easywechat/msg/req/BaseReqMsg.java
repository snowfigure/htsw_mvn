package org.easywechat.msg.req;

public class BaseReqMsg extends BaseReq {

	String msgId;

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

}
